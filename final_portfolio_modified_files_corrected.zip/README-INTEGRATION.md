# Corrected final portfolio files

Replace or add these files under `05_portfolio/`.

Included:

- `docs/index.md`: homepage with site section links and wider first table column.
- `docs/articles/index.md`: article index with clickable thumbnails using `cover-thumb.webp`.
- `docs/articles/en/*.md`: English articles using optimized `cover.webp`.
- `docs/articles/fr/*.md`: French articles using optimized `cover.webp`.
- `docs/assets/articles/*/cover.webp`: optimized article cover visuals.
- `docs/assets/articles/*/cover-thumb.webp`: optimized thumbnails for the article index.

Correction included:

- Article pages now use `../../../assets/articles/.../cover.webp`, which is required when MkDocs renders clean URLs such as `/articles/en/making-rules-visible/`.
- Article index thumbnails keep `../assets/articles/.../cover-thumb.webp`, which is correct from `/articles/`.

After replacing the files, delete the old `cover.png` files if no `.md` file references them anymore.

Recommended check:

```bash
mkdocs build --strict
grep -R "cover.png" docs/articles docs/assets || true
grep -R "../../assets/articles" docs/articles/en docs/articles/fr || true
```

If the build passes:

```bash
git add docs/index.md docs/articles docs/assets/articles
git commit -m "Fix portfolio article cover paths"
git push
mkdocs gh-deploy --clean
```
